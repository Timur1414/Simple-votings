from django.urls import path

from main import views

urlpatterns = [
    path('create/', views.voting_create_page, name='sozdanie_golosovaniya'),
    path('<int:id>/create/2/', views.voting_create_2_page, name='sozdanie_golosovaniya2'),
    path('list/', views.voting_list_page, name='list'),
    path('list/closed/', views.closed_votings_list_page, name='closed_list'),
    path('<int:id>/', views.voting_page, name='voting'),
    path('<int:id>/edit/', views.change_voting_page, name='change_voting'),
    path('<int:id>/edit/2/', views.change_voting2_page, name='change_voting2'),
    path('<int:id>/complain/', views.complain_page, name='complain'),
    path('complains_list/', views.AllComplaintsPage.as_view(), name='complains_list'),
    path('complaint_handling/<int:id>/', views.complaint_handling_page, name='complaint_handling'),
    path('complaint_status/<int:pk>/', views.ComplaintsStatusPage.as_view(), name='complaint_status'),
]
