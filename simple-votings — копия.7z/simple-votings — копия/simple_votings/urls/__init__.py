from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

from main import views
from simple_votings import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index_page, name='index'),

    path('votings/', include('simple_votings.urls.votings')),
    path('accounts/', include('simple_votings.urls.accounts')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
