import datetime
from django import forms
from django.contrib.auth import get_user_model
from django.forms import SelectDateWidget, TextInput, EmailInput
from django_registration.forms import RegistrationForm
from main.models import User, UserSettings


class CustomUserForm(RegistrationForm):
    class Meta(RegistrationForm.Meta):
        model = get_user_model()


class CreateVotingForm(forms.Form):
    TYPE_CHOICES = [
        (1, "Один вариант из набора доступных"),
        (2, "Много вариантов из набора доступных"),
        (3, "Дискретный выбор (один вариант из двух)"),
    ]
    caption = forms.CharField(
        label='Название',
        min_length=1,
        max_length=250,
        required=True
    )
    description = forms.CharField(
        label='Описание',
        widget=forms.Textarea,
        min_length=1,
        required=True
    )
    type = forms.CharField(
        label='Выберите тип голосования',
        widget=forms.RadioSelect(choices=TYPE_CHOICES)
    )
    published = forms.DateTimeField(
        label='Опубликовать голосование',
        initial=datetime.date.today,
        widget=SelectDateWidget(
            attrs={
                'style': 'display: inline-block; width: 20%;'
            }
        )
    )
    finished_time = datetime.date.today() + datetime.timedelta(7)
    finished = forms.DateTimeField(
        label='Завершить голосование',
        initial=finished_time,
        widget=SelectDateWidget(
            attrs={
                'style': 'display: inline-block; width: 20%;'
            }
        )
    )


class CreateVoting2Form(forms.Form):
    add_variant = forms.CharField(
        label='Описание ответа',
        max_length=255,
        initial=''
    )
    add_image = forms.ImageField(
        label='Добавить изображение',
        required=False
    )


class VoteVariant3Form(forms.Form):
    description1 = forms.CharField(label='Вариант 1', required=True, max_length=255)
    description2 = forms.CharField(label='Вариант 2', required=True, max_length=255)


class RegistrationForm(RegistrationForm):
    first_name = forms.CharField(label='Имя', required=True, max_length=255)
    last_name = forms.CharField(label='Фамилия', required=True, max_length=255)

    class Meta(RegistrationForm.Meta):
        model = User


class UserEditForm(forms.ModelForm):
    class Meta:
        model = get_user_model()
        fields = ('first_name', 'last_name', 'email')
        widgets = {
            'first_name': TextInput(attrs={'class': 'form-control'}),
            'last_name': TextInput(attrs={'class': 'form-control'}),
            'email': EmailInput(attrs={'class': 'form-control'}),

        }


class UserSettingsEditForm(forms.ModelForm):
    class Meta:
        model = UserSettings
        fields = ('avatar',)


class CompliantForm(forms.Form):
    description = forms.CharField(
        widget=forms.Textarea,
        min_length=1,
        required=True
    )
