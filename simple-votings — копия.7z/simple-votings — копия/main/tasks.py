from django.core.exceptions import ValidationError
from django.urls import reverse
from django.utils import timezone
from main.models import Voting
from simple_votings.celery import app
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib

from simple_votings.settings import BASE_URL, EMAIL_PASSWORD, EMAIL_SMTP_SERVER, EMAIL


def get_message(voting):
    return 'Ваше голосование закончилось. Спешите узнать результаты: ' \
              + BASE_URL + reverse('voting', kwargs={'id': voting.id})


def get_multipart_message(voting):
    msg = MIMEMultipart()
    message = get_message(voting)
    msg['From'] = EMAIL
    msg['To'] = voting.author.email
    msg['Subject'] = 'Уведомление'
    msg.attach(MIMEText(message, 'plain'))
    return msg


def send_message(msg):
    server = smtplib.SMTP(EMAIL_SMTP_SERVER)
    server.starttls()
    server.login(msg['From'], EMAIL_PASSWORD)
    server.sendmail(msg['From'], msg['To'], msg.as_string())
    server.quit()


def update_voting(voting):
    try:
        voting.email_sent = True
        voting.save()
    except ValidationError as ex:
        print('Validation error occured')
        print(f'Voting id = {voting.id}')
        print(ex)


def voting_process(voting):
    if voting.finished_at >= timezone.now():
        return
    msg = get_multipart_message(voting)
    send_message(msg)
    update_voting(voting)


@app.task
def send_email():
    print('Starting email task...')
    votings = Voting.objects.filter(email_sent=False)
    for voting in votings:
        voting_process(voting)
