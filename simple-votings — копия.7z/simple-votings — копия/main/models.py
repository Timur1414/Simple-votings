from django.contrib.auth.models import AbstractUser
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone


class User(AbstractUser):
    """
    Модель пользователя. Наследуется от абстрактного пользователя.

    :param status: Статус пользователя
    """
    status = models.CharField(max_length=255)


class UserSettings(models.Model):
    """
    Модель, хранящая настройки пользователя

    :param user: Ссылка на пользователя
    :param avatar: Аватар пользователя
    """
    user = models.OneToOneField(to=get_user_model(), on_delete=models.CASCADE)
    avatar = models.ImageField(upload_to='images/users/', max_length=250, default='images/users/no_avatar.png')


@receiver(post_save, sender=get_user_model())
def update_profile_signal(sender, instance, created, **kwargs):
    if created:
        UserSettings.objects.create(user=instance)


class Voting(models.Model):
    """
    Модель голосования

    :param author: Автор голосования
    :param caption: Заголовок (краткое описание)
    :param description: Описание голосования
    :param type: Тип голосования (1 - radio, 2 - checkbox, 3 - discrete)
    :param created_at: Дата создания
    :param published_at: Дата публикации
    :param finished_at: Дата окончания

    :param is_published: Функция, возвращающая может ли быть голосование опубликовано или нет
    :param not_published: Функция, возвращающая является ли голосование закрытым
    :param save: Сохранение
    :param clean: Валидация
    :param get_all_active_votings: Функция, возвращающая список открытых голосований
    :param get_all_close_votings: Функция, возвращающая список закрытых голосований
    :param get_all_finished_votings: Функция, возвращающая список закончившихся голосований
    :param user_has_already_voted: Функция, возвращающая участвовал ли пользователь в голосовании или нет
    :param get_all_voted_by_user: Функция, возвращающая список голосований, в которых пользователь принимал участие
    """
    author = models.ForeignKey(
        to=get_user_model(),
        on_delete=models.CASCADE
    )
    caption = models.CharField(max_length=250, default='')
    description = models.TextField(default='')
    type = models.IntegerField()
    created_at = models.DateTimeField()
    published_at = models.DateTimeField()
    finished_at = models.DateTimeField()
    email_sent = models.BooleanField(default=False)
    is_blocked = models.BooleanField(default=False)

    def is_published(self):
        if self.is_blocked:
            return False
        if self.votevariant_set.count() < 2:
            return False
        now = timezone.now()
        if now < self.published_at:
            return False
        if now > self.finished_at:
            return False
        return True

    def not_published(self):
        if self.votevariant_set.count() < 2:
            return False
        now = timezone.now()
        if now < self.published_at:
            return False
        if now > self.finished_at:
            return True
        return False

    def save(self, *args, **kwargs):
        self.full_clean()
        super(Voting, self).save(*args, **kwargs)

    def clean(self):
        if self.created_at > self.published_at:
            raise ValidationError('Нельзя устанавливать дату публикации до даты создания')

    @staticmethod
    def get_all_active_votings():
        data = Voting.objects.filter(finished_at__gt=timezone.now())
        return [item for item in data if item.is_published()]

    @staticmethod
    def get_all_close_votings():
        data = Voting.objects.filter(finished_at__lt=timezone.now())
        return [item for item in data if item.not_published()]

    @staticmethod
    def get_all_finished_votings():
        data = Voting.objects.filter(finished_at__lte=timezone.now())
        return [item for item in data if item.is_published()]

    def user_has_already_voted(self, user):
        variants = self.votevariant_set.all()
        facts = VoteFact.objects.filter(user=user, variant__in=variants)
        return facts.count() > 0

    @staticmethod
    def get_all_voted_by_user(user):
        facts = VoteFact.objects.filter(user=user)
        result = []
        for fact in facts:
            if fact.variant.voting not in result:
                result.append(fact.variant.voting)
        return result


class VoteVariant(models.Model):
    """
    Модель, хранящая вариант ответа к голосованию

    :param voting: Ссылка на голосование
    :param description: Описание ответа
    :param position: Позиция ответа (не используется)
    :param image: Путь к файлу

    :param save_object: Функция, создающая запись в таблице
    """
    voting = models.ForeignKey(
        to=Voting,
        on_delete=models.CASCADE
    )
    description = models.CharField(max_length=250)
    position = models.IntegerField()
    image = models.ImageField(upload_to='images/votevariants/', max_length=250, default='')

    @staticmethod
    def save_object(voting, description='', position=0, image=None):
        record = VoteVariant(
            voting=voting,
            description=description,
            position=position,
        )
        if image is not None:
            record.image = image
        record.save()


class VoteFact(models.Model):
    """
    Модель, хранящая факт голосования пользователя за какой-то ответ

    :param user: Ссылка на пользователя
    :param variant: Ссылка на ответ
    """
    user = models.ForeignKey(
        to=get_user_model(),
        on_delete=models.CASCADE
    )
    variant = models.ForeignKey(
        to=VoteVariant,
        on_delete=models.CASCADE
    )


class Compliant(models.Model):
    """
    Модель жалобы. При создании используется или ссылка на голосование или ссылка на ответ

    :param voting: Ссылка на голосование
    :param author: Ссылка на пользователя
    :param description: Описание жалобы
    :param status: Статус жалобы 1- отправлена, 2 - принята (голосование блокируется), 3 - отказ (голосование не изменяется)
    :param created_at: Дата создания
    :param solved_at: Дата рассмотрения

    :param __str__: Функция, преобразующая объект в строку. Возвращает описание
    """
    voting = models.ForeignKey(
        to=Voting,
        on_delete=models.CASCADE
    )
    author = models.ForeignKey(
        to=get_user_model(),
        on_delete=models.CASCADE
    )
    description = models.TextField(default='')
    status = models.IntegerField()
    created_at = models.DateTimeField()
    solved_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.description
