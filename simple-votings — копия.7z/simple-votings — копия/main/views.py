import datetime
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.http import Http404
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.utils.decorators import method_decorator
from main.forms import CreateVotingForm, VoteVariant3Form, CreateVoting2Form, \
    UserEditForm, UserSettingsEditForm, CompliantForm
from main.models import Voting, User, VoteVariant, VoteFact, UserSettings, Compliant
from django.views.generic import ListView, DetailView


def get_menu_context():
    return [
        {'url_name': 'index', 'name': 'Главная'},
        {'url_name': 'list', 'name': 'Список голосований'},
    ]


def index_page(request):
    """
    Главная страница. Лендинг

    :param context: Словарь для наполнения страницы
    :param request: Запрос
    :return: HTML страница
    """
    context = {
        'pagename': 'Главная',
        'menu': get_menu_context()
    }
    return render(request, 'pages/index.html', context)


def voting_list_page(request):
    """
    Страница с голосованиями. Каждое голосование отображается карточкой-ссылкой. На этой странице только
    открытые голосования

    :param context: Словарь для наполнения страницы
    :param votings: Все голосования
    :param voted_votings: Голосования, в которых пользователь принимал участие
    :param request: Запрос
    :return: HTML страница
    """
    context = {
        'pagename': 'Список',
        'menu': get_menu_context(),
    }
    votings = Voting.get_all_active_votings()
    context['votings'] = votings
    context['now'] = timezone.now()
    if request.user.is_authenticated:
        context['voted_votings'] = Voting.get_all_voted_by_user(request.user)
    return render(request, 'pages/voting_list.html', context)


def closed_votings_list_page(request):
    """
    Страница с голосованиями. Каждое голосование отображается карточкой-ссылкой. На этой странице только
    закрытые голосования

    :param context: Словарь для наполнения страницы
    :param votings: Все голосования
    :param voted_votings: Голосования, в которых пользователь принимал участие
    :param request: Запрос
    :return: HTML страница
    """
    context = {
        'pagename': 'Закрытые голосования',
        'menu': get_menu_context(),
    }
    votings = Voting.get_all_close_votings()
    context['votings'] = votings
    context['now'] = timezone.now()
    return render(request, 'pages/closed_votings_list.html', context)


@login_required()
def voting_create_page(request):
    """
    Страница создания голосования (1 из 2). В неё входят: создание заголовка и вопроса, типа, дат проведения. Страница
    доступна только авторизированным пользователям

    :param context: Словарь для наполнения страницы
    :param form: Форма создания голосования
    :param record: Новое голосование
    :param request: Запрос

    :type form: ``main.forms.CreateVotingForm``

    :return: HTML страница
    """
    context = {
        'pagename': 'Создание голосования',
        'menu': get_menu_context()
    }
    if request.method == 'POST':
        form = CreateVotingForm(request.POST)
        if form.is_valid():
            id = -1
            try:
                record = Voting(
                    author=request.user,
                    caption=form.cleaned_data['caption'],
                    description=form.cleaned_data['description'],
                    type=form.cleaned_data['type'],
                    created_at=datetime.date.today(),
                    published_at=form.cleaned_data['published'],
                    finished_at=form.cleaned_data['finished'],
                )
                record.save()
                id = record.id
            except ValidationError as ex:
                errors = ex
                context['errors'] = errors
                return render(request, 'pages/create_voting/1.html', context)
            return redirect(to='sozdanie_golosovaniya2', id=id)
    else:
        form = CreateVotingForm()
    context['form'] = form
    return render(request, 'pages/create_voting/1.html', context)


def voting_create_page_type12(voting, context, request):
    """
    Эта функция обрабатывает запрос с страницы "Созздание голосования". Только 1 и 2 тип.

    :param voting: Голосование, к которому создаются ответы
    :param context: Словарь для наполнения страницы
    :param request: Запрос
    :param variants: Варианты ответов к голосованию
    :param form: Форма доюавления ответов
    :return: Ничего или стоку "redirect", если надо перенаправить пользователя
    """
    variants = VoteVariant.objects.filter(voting=voting.id)
    context['variants'] = variants
    if request.method == 'POST':
        form = CreateVoting2Form(request.POST, request.FILES)
        if form.is_valid():
            image = request.FILES.get('add_image')
            VoteVariant.save_object(
                voting=voting,
                description=form.cleaned_data['add_variant'],
                image=image
            )
            return 'redirect'
    else:
        form = CreateVoting2Form()
    context['form'] = form


def voting_create_page_type3(voting, context, request):
    """
    Эта функция обрабатывает запрос с страницы "Созздание голосования". Только 3 тип.

    :param voting: Голосование, к которому создаются ответы
    :param context: Словарь для наполнения страницы
    :param request: Запрос
    :param variants: Варианты ответов к голосованию
    :param form: Форма доюавления ответов
    :return: ничего или строку "redirect", если надо перенаправить пользователя
    """
    if request.method == 'POST':
        form = VoteVariant3Form(request.POST)
        if form.is_valid():
            for description_name in ['description1', 'description2']:
                VoteVariant.save_object(
                    voting=voting,
                    description=form.cleaned_data[description_name]
                )
            return 'redirect'
    else:
        form = VoteVariant3Form()
        context['form'] = form


@login_required()
def voting_create_2_page(request, id):
    """
    Страница создания голосования (2 из 2). В неё входит добавление ответов. Страница доступна только авторизированным пользователям

    :param context: Словарь для наполнения страницы
    :param voting: Голосование, созданное на предыдущей странице
    :param request: Запрос
    :param id: ID голосования
    :return: HTML страница
    """
    context = {
        'pagename': 'Создание голосования2',
        'menu': get_menu_context()
    }
    voting = get_object_or_404(Voting, id=id)
    context['voting'] = voting
    if voting.type != 3:
        result = voting_create_page_type12(voting, context, request)
        if result == 'redirect':
            return redirect(to='sozdanie_golosovaniya2', id=id)
    else:
        result = voting_create_page_type3(voting, context, request)
        if result == 'redirect':
            return redirect(to='index')
    return render(request, 'pages/create_voting/2.html', context)


def voting_page(request, id):
    """
    Страница голосования. Отображает автора голосования, само голосование, даты проведения и, если пользователь авторизирован, то
    варианты ответов, за которые можно проголосовать. Если голосование закончено, то показывает сколько голосовов набрал каждый
    из вариантов. Если голосование ещё не закончено, но пользователь уже проголосовал, то показывает его ответ (без возможности
    отменить голос)

    :param context: Словарь для наполнения страницы
    :param keys: ID вариантов, за которые проголосовал пользователь
    :param vote_facts: Записи из БД, которые фильтруются по пользователю. Если ответ прикреплён к текущему голосованию, то он сохраняется
    :param variants: Список сохранённых вариантов ответа из ``vote_facts``
    :param voted_variants: Варианты, за которые проголосовал пользователь
    :param variants: Все варианты ответа, которые прикреплены к текущему голосованию
    :param request: Запрос
    :param id: ID текущего голосования
    :return: HTML страница
    """
    context = {
        'pagename': 'Голосование',
        'menu': get_menu_context(),
        'user': request.user,
    }
    voting = get_object_or_404(Voting, id=id)
    context['voting'] = voting
    if request.method == 'POST':
        keys = request.POST.getlist('variant_id')
        if 'undefined' in keys:
            keys = []
        for key in keys:
            tmp_voting = VoteVariant.objects.filter(id=int(key))[0]
            record = VoteFact(
                user=request.user,
                variant=tmp_voting
            )
            record.save()
    if request.user.is_authenticated:
        vote_facts = VoteFact.objects.filter(user=request.user)
        voted_variants = []
        for vote_fact in vote_facts:
            if vote_fact.variant.voting.id == id:
                voted_variants.append(vote_fact.variant)
        context['voted'] = len(voted_variants) > 0
        context['voted_variants'] = voted_variants
    variants = VoteVariant.objects.filter(voting=id)
    context['variants'] = variants
    results = []
    count_votefacts = 0
    for variant in variants:
        results.append(len(VoteFact.objects.filter(variant=variant)))
        count_votefacts += results[-1]
    if count_votefacts == 0:
        count_votefacts = 1
    for i in range(len(results)):
        results[i] = int(results[i] * 100 / count_votefacts)
    context['results'] = results
    context['now'] = timezone.now()
    return render(request, 'pages/voting/type_' + str(voting.type) + '.html', context)


@login_required()
def change_voting_page(request, id):
    """
    Страница редактирования голосования (1 из 2). Здесь можно редактировать заголовок, описание и тип голосования.
    Страница доступна только авторизированным пользователям, которые являются авторами голосований

    :param context: Словарь для наполнения страницы
    :param voting: Голосование для редактирования
    :param form: Форма создания голосования
    :param request: Запрос
    :param id: ID голосования

    :type form: ``main.forms.CreateVotingForm``

    :return: HTML страница
    """
    context = {
        'pagename': 'Редактирование голосования',
        'menu': get_menu_context(),
    }
    voting = get_object_or_404(Voting, id=id)
    if request.user == voting.author:
        context['user_is_author'] = True
    else:
        context['user_is_author'] = False
    context['voting'] = voting
    context['type'] = voting.type - 1
    if request.method == 'POST':
        if request.POST.get('delete_voting'):
            Voting.objects.get(id=id).delete()
            return redirect(to='index')
        form = CreateVotingForm(request.POST)
        if form.is_valid():
            Voting.objects.filter(id=id).update(
                caption=form.cleaned_data['caption'],
                description=form.cleaned_data['description'],
                type=form.cleaned_data['type'],
                created_at=timezone.now(),
                published_at=form.cleaned_data['published'],
                finished_at=form.cleaned_data['finished']
            )
            return redirect(to='change_voting2', id=id)
    else:
        form = CreateVotingForm()
    context['form'] = form
    return render(request, 'pages/edit_voting/1.html', context)


@login_required()
def change_voting2_page(request, id):
    """
    Страница редактирования голосования (2 из 2). Позволяет редактировать варианты ответа. Доступна
    только авторизированным пользователям

    :param context: Словарь для наполнения страницы
    :param voting: Редактируемое голосование
    :param variants: Варианты ответа к голосованию
    :param form: Форма создания голосования 2
    :param request: Запрос
    :param id: ID голосования
    :return: HTML страница
    """
    context = {
        'pagename': 'Редактирование голосования',
        'menu': get_menu_context(),
    }
    voting = get_object_or_404(Voting, id=id)
    if request.user == voting.author:
        context['user_is_author'] = True
    else:
        context['user_is_author'] = False
    context['voting'] = voting
    variants = VoteVariant.objects.filter(voting=voting.id)
    form = CreateVoting2Form()
    if voting.type == 3:
        if request.method == 'POST':
            form = VoteVariant3Form(request.POST)
            if form.is_valid():
                for i in range(len(variants)):
                    if i < 2:
                        VoteVariant.objects.filter(id=variants[i].id).update(
                            description=form.cleaned_data['description' + str(i + 1)]
                        )
                    else:
                        VoteVariant.objects.filter(id=variants[i].id).delete()
                return redirect(to='index')
        else:
            form = VoteVariant3Form()
    else:
        if request.method == 'POST':
            if request.POST.get('delete', False):
                if len(variants) > 2:
                    id = request.POST.get('delete', '-1')
                    if id.isdigit() and id != '-1':
                        variant = get_object_or_404(VoteVariant, id=id)
                        variant.delete()
                        variants = VoteVariant.objects.filter(voting=voting.id)
                    else:
                        raise Http404
                    form = CreateVoting2Form()
            else:
                form = CreateVoting2Form(request.POST, request.FILES)
                if form.is_valid():
                    print(request.FILES)
                    image = request.FILES.get('add_image')
                    VoteVariant.save_object(
                        voting=voting,
                        description=form.cleaned_data['add_variant'],
                        image=image
                    )
                    return redirect(to='change_voting2', id=id)
    context['form'] = form
    context['variants'] = variants
    return render(request, 'pages/edit_voting/2.html', context)


@login_required()
def profile_page(request, username):
    """
    Страница профиля. Доступна только авторизированным пользователям. На ней есть список
    голосований, созданных этим пользователем, список голосований, в которых пользователь
    принимал участие, список его жалоб, информация о пользователе, аватар, ссылки на страницы
    со сменой пароля и информации о пользователе.

    :param request: Запрос
    :param username: Логин пользователя
    :param context: Словарь для наполнения страницы
    :param user: Пользователь
    :return: HTML страница
    """
    context = {
        'pagename': username,
        'menu': get_menu_context(),
    }
    user = get_object_or_404(User, username=username)
    context['user'] = user
    if request.user.username == username:
        context['user_is_author'] = True
    else:
        context['user_is_author'] = False

    UserSettings.objects.get_or_create(user=request.user)
    context['created_votings'] = Voting.objects.filter(author=user)

    vote_facts = VoteFact.objects.filter(user=user)
    variants = [fact.variant for fact in vote_facts]

    voted_votings = []
    for variant in variants:
        if variant.voting not in voted_votings:
            voted_votings.append(variant.voting)

    context['complaints'] = Compliant.objects.filter(author=user)

    context['voted_votings'] = voted_votings
    context['now'] = timezone.now()

    return render(request, 'pages/profile/details/index.html', context)


@login_required()
def password_change_done(request):
    logout(request)
    return redirect('login')


@login_required()
def user_edit_page(request, username):
    """
    Страница редактирования данных о пользователе. Доступна только авторизированным
    пользователям. На странице присутствует две формы: с текстовой информацией и аватаром

    :param request: Запрос
    :param username: Логин пользователя
    :param context: Словарь для наполнения страницы
    :param user_form: Форма с текстовой информацией
    :param user_settings_form: Форма с картинкой
    :return: HTML страница
    """
    if request.user.username != username:
        raise Http404
    context = {
        'pagename': 'UserEdit',
        'menu': get_menu_context(),
    }
    if request.method == 'POST':
        user_form = UserEditForm(instance=request.user, data=request.POST)
        user_settings_form = UserSettingsEditForm(instance=request.user.usersettings, data=request.POST,
                                                  files=request.FILES)
        if user_form.is_valid() and user_settings_form.is_valid():
            user_form.save()
            user_settings_form.save()
    else:
        user_form = UserEditForm(instance=request.user)
        user_settings_form = UserSettingsEditForm(instance=request.user.usersettings)
    context['user_form'] = user_form
    context['user_settings_form'] = user_settings_form
    return render(request, 'pages/profile/edit/user.html', context)


@login_required()
def complain_page(request, id):
    """
    Страница создания жалобы. Доступна только авторизированным пользователям

    :param request: Запрос
    :param id: ID голосования
    :param context: Словарь для наполнения страницы
    :param vote: Голосование, на которое создаётся жалоба
    :param complain_form: Форма создания жалобы
    :return: HTML страница
    """
    context = {
        'pagename': 'Пожаловаться',
        'menu': get_menu_context(),
    }
    vote = get_object_or_404(Voting, id=id)
    context['voting'] = vote
    if request.method == 'POST':
        complain_form = CompliantForm(request.POST)
        if complain_form.is_valid():
            new_compliant = Compliant(
                description=complain_form.cleaned_data['description'],
                voting=vote,
                author=request.user,
                status=1,
                created_at=timezone.now(),
            )
            new_compliant.save()
            return redirect(to='index')

    else:
        complain_form = CompliantForm()
    context['complain_form'] = complain_form
    return render(request, 'pages/complaints/complain.html', context)


@method_decorator(staff_member_required, name='dispatch')
class AllComplaintsPage(ListView):
    """
    Страница списка жалоб. Доступна только пользователям is_staff

    :param model: Модель представления
    :param template_name: Шаблон представления
    :param context_object_name: Переменная контекста для объектов модели
    :param extra_context: Дополнительные переменные контекста (title страницы и меню)
    :param get_queryset: Функция, возвращающая только объекты со статусом 1
    :return: HTML страница
    """
    model = Compliant
    template_name = 'pages/complaints/complains_list.html'
    context_object_name = 'complanes'
    extra_context = {
        'menu': get_menu_context(),
        'pagename': 'Нерассмотренные обращения'
    }

    def get_queryset(self):
        return Compliant.objects.filter(status=1)


@staff_member_required
def complaint_handling_page(request, id):
    """
    Страница рассмотрения жалоб. Доступна только пользователям is_staff

    :param compliant: Жалоба к рассмотрению
    :param vote: Голосование на которое составлена жалоба
    :param vote_compliants: Все жалобы оставленные на голосование vote
    :param pagename: Дополнительная переменная контекста (title страницы)
    :param menu: Дополнительная переменная контекста (меню)
    :param request: Запрос
    :param id: ID жалобы
    :return: HTML страница
    """

    context = {
        'pagename': 'Рассмотрение жалобы',
        'menu': get_menu_context(),
    }
    compliant = get_object_or_404(Compliant, id=id)
    context['compliant'] = compliant
    vote = get_object_or_404(Voting, id=compliant.voting.id)
    if request.method == 'POST':
        if request.POST.get('accept_complaint'):
            compliant.status = 2
            compliant.solved_at = timezone.now()
            compliant.save()
            vote.is_blocked = True
            vote.save()
        elif request.POST.get('cancel_complaint'):
            compliant.status = 3
            compliant.solved_at = timezone.now()
            compliant.save()
        return redirect(to='complains_list')
    return render(request, 'pages/complaints/complaint_handling.html', context)


@method_decorator(login_required, name='dispatch')
class ComplaintsStatusPage(DetailView):
    """
    Страница просмотра статуса жалобы

    :param model: Модель представления
    :param template_name: Шаблон представления
    :param context_object_name: Переменная контекста для объектов модели
    :param extra_context: Дополнительные переменные контекста (title страницы и меню)
    :param get_queryset: Функция, возвращающая только объекты со статусом 1
    :return: HTML страница
    """
    model = Compliant
    template_name = 'pages/complaints/complain_status.html'
    context_object_name = 'compliant'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['menu'] = get_menu_context()
        context['pagename'] = 'Статус обращения'
        obj = self.object
        context['solved_at'] = obj.solved_at if obj.solved_at is not None else ''
        result = ''
        if obj.status == 2:
            result = 'Голосование заблокировано'
        elif obj.status == 3:
            result = 'Голосование оставлено без изменений'
        context['result'] = result
        return context
