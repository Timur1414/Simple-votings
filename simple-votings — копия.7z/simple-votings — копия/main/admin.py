from django.contrib import admin

# Register your models here.
from main.models import UserSettings

admin.site.register(UserSettings)
