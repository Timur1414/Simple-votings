Документация разработчика
=========================

******
Models
******

.. automodule:: main.models
    :members:

*****
Views
*****

.. automodule:: main.views
    :members:
