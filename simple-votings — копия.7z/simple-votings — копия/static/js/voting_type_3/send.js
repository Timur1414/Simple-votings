function set_id(obj) {
  'use strict'
  id_input.value = obj.name
}
